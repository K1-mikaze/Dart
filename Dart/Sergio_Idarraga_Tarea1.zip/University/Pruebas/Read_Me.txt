Hola profesor Porfirio, 
Como pudiste evidencia estoy utilizando una distribucion de linux llamada NixOS por lo tanto no tengo instalado Visual Studio Community debido a que no existe una version para linux almenos compatible con mi distribucion. 

Sin embargo, mi maquina tiene un dual-boot por lo tanto tambien tengo Windows y en ese sistema operativo si lo tengo instalado. 

Ademas en flutter doctor hay un error con android-studio que no encuentra la ruta hacia el JDK de java incluso dandosela, es un error de android-studio para esta version q estoy utilizando, sin embargo funciona totalmente sin imprevistos.

Muchas gracias y espero que puedas entenderlo.
Att: Sergio Idarraga
CC 1112759822
