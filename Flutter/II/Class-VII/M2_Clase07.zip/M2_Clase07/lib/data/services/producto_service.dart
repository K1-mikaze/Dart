import 'package:inventario/data/models/models.dart';

class ProductoService {


} // fin de la clase ProductoService
