export 'package:inventario/utils/validators/validar_formulario.dart';
