export 'package:inventario/view/screens/producto_view_screen.dart';
export 'package:inventario/view/screens/producto_list_screen.dart';
export 'package:inventario/view/screens/producto_form_screen.dart';