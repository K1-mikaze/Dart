class Calificacion {
  final String estudiante;
  final String asignatura;
  final double nota;
  final String imagen;

  Calificacion({required this.imagen, required this.estudiante, required this.asignatura, required this.nota});

}